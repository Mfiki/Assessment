describe('ULTIMATE_QA', () => {
  beforeEach(() => {
    cy.visit('https://www.ultimateqa.com/automation/')
});

  it('Take Screenshot', () => {
    cy.screenshot()
  })

  it('Maximize Window', () => {
    cy.viewport(1280, 720)
  })

  it('Fill out forms', () => {
    cy.get('.et_pb_text_inner > ul > :nth-child(4) > a').click()
    cy.get('#et_pb_contact_name_0').type("test")
    cy.get('#et_pb_contact_message_0').type("This is test message")
    cy.get('#et_pb_contact_form_0 > .et_pb_contact > .et_pb_contact_form > .et_contact_bottom_container > .et_pb_contact_submit')
      .click()
  })

  it('Fake Pricing Page', () => {
    cy.get('.et_pb_text_inner > ul > :nth-child(3) > a').click()
    cy.get('.et_pb_column_2 > .et_pb_with_border > .et_pb_pricing_table_wrap > .et_pb_pricing_table > .et_pb_button_wrapper > .et_pb_button')
  }) 
})

describe('Login/ Logout', () => {
  beforeEach(() => {
    cy.visit('https://courses.ultimateqa.com/users/sign_in')
    });
  it('Login to Ultimate QA', () => {
    cy.get('#user\\[email\\]').type("testqa@test.com")
    cy.get('#user\\[password\\]').type("password1234$")
    cy.get('.form__button-group > .button').click()
  })

  it('Logout', () => {
    cy.get('#user\\[email\\]').type("testqa@test.com")
    cy.get('#user\\[password\\]').type("password1234$")
    cy.get('.form__button-group > .button').click()
    cy.get('.dropdown__toggle-button > .fa').click()
    cy.get('#header-dropdown-menu > :nth-child(4) > a').click()
  })
})